<?php  

$_SESSION['tabRef'] = NULL;
$_SESSION['tabQte'] = NULL;




	
echo "<div class = 'corps'>
		<h1>Le panier a bien été vidé, vous pouvez poursuivre votre visite sur le site.<h1/>
		
		</div>
		";







?>