<?php 


$r = selectActu($co);
echo "<div class ='boxH'>";
affActu($co, $r);
echo "</div>";







?>