<div class="contenu">


<div class = "box">

<h1>Bienvenue Chez Naïg Coiffure.</h1>
<p>

<br/>
<br/>

Au cœur d’Acigné, Naïg et son équipe vous accueillent dans une atmosphère conviviale pour vous offrir un moment de détente et de bien-être !
</p>
<ul>
<li>Venez profiter de nos toutes nos prestations : nous sommes à l'écoute de tous vos désirs.</li>
<li> Vous avez envie de changer de coupe, de couleur ou simplement envie de changer de style,
vous avez besoin de conseils, d'idées nouvelles … </li> 
<li> Nous vous conseillerons et vous guiderons vers les coupes et les services qui vous conviennent.</li>

</ul> 

  
</div>

<div class = "box">

<h1>Coiffure femmes</h1>
<?php include "galerieFemme.html"?>

<p class = "sideTxt">  	
 
En fonction de vos envies,<br/>
nous vous conseillons pour une coiffure adaptée à la morphologie de votre visage. adaptée des coupes modernes ou classiques stylées.<br/>
 
Nos services sont très variés, relooking coiffure, lissage, défrisage, couleurs mèches, permanentes et mises en forme.<br/>

Notre salon coiffure expert en coloration saura vous conseiller et vous apporter la meilleure solution pour vous satisfaire.<br/> </p>
</div>


<div class = "box">

<h1>Coiffure Hommes</h1>
<?php include "galerieHomme.html"?>

<p class = "sideTxt">  	Tous les styles se déclinent chez Naïg, Que vous soyez sportif, classique, moderne nous vous orientons et vous conseillons pour une coiffure unique et adaptée.
 
</p>
</div>

<div class = "box">

<h1>Coiffure Junior</h1>
<?php include "galerieJunior.html"?>

<p class = "sideTxt">  	Pour vous aider dans votre choix, Naïg vous propose de découvrir les dernières coupes de cheveux tendances et ce qui se fait de mieux en matière de coiffure.
 
</p>
</div>
 

</div>