<form   action = "../outils/connexion.php" method = "post" >

<label>Identifiant</label>
<input name="id"></input>
<br>
<label>Mot de passe</label>
<input type = "password" name ="mdp"></input>

<br>

<button type = "submit" >Valider</button>

</form>