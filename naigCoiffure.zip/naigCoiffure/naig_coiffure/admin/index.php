<?php
session_start ();



?>






<!DOCTYPE html>
<html>
<head>
<meta content="text/html" ; charset="utf-8" />
<link rel="stylesheet" href="../styles/style.css" />
<link rel="stylesheet" type="text/css"
	href="http://fonts.googleapis.com/css?family=Tangerine">
<link rel="stylesheet" type="text/css"
	href="http://fonts.googleapis.com/css?family=Indie+Flower">
<script type="text/javascript"
	src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>


<title>Naïg Coiffure</title>
</head>

<body>


	<div class="corps">

<?php 



include ("../pages/fConnexion.php");



?>

</div>


</body>
</html>