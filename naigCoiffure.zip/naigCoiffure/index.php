<?php      
  header('Location: /');      
?>